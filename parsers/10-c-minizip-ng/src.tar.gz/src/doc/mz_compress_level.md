# MZ_COMPRESS_LEVEL

Compression level enumeration.

|Name|Code|Description|
|-|-|-|
|MZ_COMPRESS_LEVEL_DEFAULT|-1|Default compression level (6)|
|MZ_COMPRESS_LEVEL_FAST|2|Fast compression level|
|MZ_COMPRESS_LEVEL_NORMAL|6|Mid compression level|
|MZ_COMPRESS_LEVEL_BEST|9|Slow compression level|