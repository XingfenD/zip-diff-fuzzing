/*
 *	Copyright (c) 2003 Guido Draheim <guidod@gmx.de>
 *      Use freely under the restrictions of the ZLIB license.
 *
 *      This file is used as an example to clarify zzip api usage.
 */

extern int
unzzip_show_list(int argc, char** argv);
extern int
unzzip_long_list(int argc, char** argv);
