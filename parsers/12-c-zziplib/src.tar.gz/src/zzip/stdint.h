#ifndef _ZZIP__STDINT_H
#define _ZZIP__STDINT_H 1

/* obsolete header - use zzip/cstdint.h instead */

#include <zzip/cstdint.h>

#endif /*_ZZIP_STDINT_H*/
