<date> 2004 </date>

## COPYING - license information 
the public license terms

The zziplib is a small library that allows for some parts of
obfuscation. This is very handy in commercial projects which tend
to incorporate a copy into their source tree. And with 
[obfuscation](zzip-xor.htm) it is often advisable 
to staticlink the zziplib part and `strip` the symbols from 
the resulting binary - in order to obfuscate the usage of a 
standard library for semi-`encryption` of data files.

In the past I have been modifying the original LGPL license
with a text that allows staticlinking thereby taking over a
few paragraphs from the MPL as restrictions to do so, just to 
defend against improper usage. However I kept being asked 
legalese questions since most people do not want to interpret 
added text either and on their own without a lawyer. However
that accounts to me as well.

The public license(s) are simply there to protect me and
my work, none of this is fixed and it is neither the only 
possible way to get hold of a proper license. You can 
always contact me to negotiate a special one if you do 
need so. In most cases I will just say okay and you get 
it for free, perhaps after some presentations I will 
ask for som tax-reductable compensation sent to
a wellfare organisation (never me!).

A last hint from a friend did make me think as well, as
that the whole point of using standard public licenses
is to protect against the need to use your own lawyers
in the case that someone breaks the license rules. If
one uses a standard license then it is in the interest
of that big organization XY that the license will be
enforced and that it will be shown valid in all courts.
At the time of writing, no opensource license has
ever been discussed to an end in a court trial.

That's why at last, I decided to change the COPYING 
details once again - and start shipping under a dual
MPL / LGPL license where each of them is separate 
and restrictions apply alternatively. Remember that 
each license is non-exclusive anyway, and I can give
out as many licenses as I want, here we have one as
MPL, then we have one as LGPL, and perhaps you ask me
for a third text to send you over. The public ones
are just there for you as a free choice which you can
pick without negotiations or a fee.

And yes, you will be on established legal grounds as 
long as you restrict your usage of the library to the 
details contained in either COPYING text. And better
yet, the legal possibilities have been discussed
a few hundred times before. You will surely find
good answers on the internet as well to guide you
to decisions in your company whether zziplib may
be adopted for a specific task.

The sources themselves are sent out under a dual license, 
with both MPL and LGPL license options, and as long as 
the MPL part is  not removed then the recpient of some
modified sources will be entitled to the same choice
among the public licenses of LGPL / MPL. Note that some
example sources are given away under the ZLIB license
which is nothing more than asking for nice behavior 
which should have been the case even without such a text.

As for staticlinking, let us explore that a bit - there has 
been a debate that the LGPL warrants in fact the freedom of 
the final recipient as you must give him the original or 
modified sources of zziplib, to allow them to modify that 
part again, and then (re-)link to your own parts. Your own
parts may come in the form of precompiled objects without
sources (as opposed to the GPL restrictions). In here, it
is simply easier to use a dynamic linker that does the 
re-linking job at startup-time of the whole project instead 
to provide a makefile and linkage descriptions to let the
user do the staticlink it into a combined executable object. 
The latter however is often needed for embedded environments
and it is quite of the original motivation to ask for a
staticlink option where in fact the LGPL does allow it anyway
as long as you ship all parts separatly as well.

The MPL defines the area of a combined work a bit differently,
in a way it derives some ideas from BSD'ish licenses. This
part does more care to protect the `Intellectual Properties`
of the original developers. It does ask to prominently show 
off that you have gone to link with the work of someone else 
in your project. Take special note of *"3.5 Required Notices"*,
*"3.6 Distribution of Executable Versions"* and
*"3.7 Larger Works"* here. Or read a lawyer text on
the legal result of the whole license.
