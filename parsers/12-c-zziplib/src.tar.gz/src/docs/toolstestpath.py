#! /usr/bin/python3

import sys
print(sys.path)
sys.path += ["."]
print(sys.path)

