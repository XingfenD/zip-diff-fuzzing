<date> 2009-08-23 </date>

## Developer 
sourceforge SVN area

<center>
<a href="http://zziplib.svn.sourceforge.net/viewvc/zziplib/">
         http://zziplib.svn.sourceforge.net/viewvc/zziplib/ </a>
</center>

The zziplib is using the Subversion repository of sourceforge
for development. (originally it used the cvs service but it
is now switched over to the svn serivce) Since 0.13.x the zziplib
is using the version control system as the main area to host
the source code in the module "zzip-0". You can get a snapshot
from that area anytime, the access details can be found under the
link above. All later releases are actually snapshots of some
cvs day. (Prior releases had seen too many reshuffling of the
build system which cvs is not the best tool to handle gracefully.
Since the switch to svn also refactoring can be tracked just fine).

I was using the sourceforge compilefarm to do remote testing of
releases for crossplatform compatibility. This included usually
some unix compatible platforms such as Linux, Solaris,
FreeBSD, Darwin/MacOSX including i386, amd64, sparc, sparc64,
powerpc when available. Even the latest daytoday cvs snapshots
should be fine for these platforms. However sourceforge has
shut down the compilefarm just as HP closed the teamdrive
service for the public. At the moment I am using the buildservice
at build.opensuse.org to test multiple platforms atleast with
the help of a "make check" minimal unittest during the rpmbuild.

In the labs of my former employer some more platforms exist but these
were only checked once in a few months, mostly summertime and christmas
season if the general workload is low. That included hp/ux but more
importantly a real MSVC6 installation and a few PCs with win32 flavours.
I do not use win32 at home! Any help in that area is greatly appreciated,
the zziplib was written in strict ansi-C but the build system and dll hell
is sometimes very weird for win32 platforms. I feel it often requires
experienced hands to detect the source of a problem should there be one.

Note also that I do not use PHP, there is a regular flow of questions
circulating around the php-zip module which is built around zziplib. But
I can not answer any questions about the build and installation for that.
It would be greatly appreciated if I can find contact to a PHP hacker
to whom I can forward php related mails! The php zip wrapper is not part
of the zziplib in any way.

Since there is an MSVC6 system in reach now, I have not been updating my
gcc/mingw32 installations as rigidly as most other win32 developers
have. I understand there are great advancements in the msys/mingw32 area
and the provided technology which made them follow quickly. However in
the labs only some older releases are used for these are called more
"stable". Remember that I do not use win32 at home, only crosscompile to
mingw32 is checked out sometimes but I know that it is somewhat different
than the selfhosted msys environment. Any help is greatly appreciated.

Lastly, I am trying to make the zziplib as close as possible to the
  thing called "industrial strength". But remember that this is still
  an opensource spare time probject. **I take patches**! Many of the
  interesting parts of zziplib have been introduced by submission which
  I have later integrated more heavily to make the zziplib be what it
  was always intended for: to be a small, fast and portable library allowing
  to use a zip file as a special variant of a data filesystem. The ext/io
  obfuscation stuff was one of the best feature submissions so far. Thanks.

Looking forward to hear from *YOU*.
  - [guidod@gmx.de](mailto:guidod@gmx.de?subject=zzip:)
