// StdAfx.h

#if _MSC_VER >= 1800
#pragma warning(disable : 4464) // relative include path contains '..'
#endif
#include "../../UI/FileManager/StdAfx.h"
